import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import VideoExamples from '@/components/VideoExamples';
import ContentGenerator from '@/components/ContentGenerator';
import HowItWorks from '@/components/HowItWorks';
import PricingSection from '@/components/PricingSection';
import VideoResult from '@/components/VideoResult';
import CTASection from '@/components/CTASection';
import Footer from '@/components/Footer';

function App() {
  const [selectedEmotion, setSelectedEmotion] = useState('');
  const [keyword, setKeyword] = useState('');
  const [user, setUser] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [contentType, setContentType] = useState('video');
  const [currentView, setCurrentView] = useState('home');
  const { toast } = useToast();

  const emotions = [
    { id: 'motivation', name: 'Motivación', icon: 'TrendingUp', color: 'from-orange-500 to-red-500' },
    { id: 'sadness', name: 'Tristeza', icon: 'Heart', color: 'from-blue-500 to-purple-500' },
    { id: 'betrayal', name: 'Traición', icon: 'Zap', color: 'from-red-500 to-pink-500' },
    { id: 'overcoming', name: 'Superación', icon: 'Target', color: 'from-green-500 to-blue-500' },
    { id: 'inspiration', name: 'Inspiración', icon: 'Sparkles', color: 'from-yellow-500 to-orange-500' },
    { id: 'reflection', name: 'Reflexión', icon: 'Star', color: 'from-purple-500 to-indigo-500' }
  ];

  useEffect(() => {
    const savedUser = localStorage.getItem('viralmind_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const checkDailyLimit = (user) => {
    if (!user || user.isPremium) return { canGenerate: true, remaining: 'ilimitados' };
    
    const today = new Date().toDateString();
    const todayVideos = (user.videos || []).filter(video => 
      new Date(video.createdAt).toDateString() === today
    );
    
    const dailyLimit = 2;
    const remaining = Math.max(0, dailyLimit - todayVideos.length);
    
    return {
      canGenerate: remaining > 0,
      remaining: remaining,
      used: todayVideos.length,
      limit: dailyLimit
    };
  };

  const generateVideoScript = (keyword, emotion) => {
    const scripts = {
      motivation: {
        éxito: "🔥 El ÉXITO no es casualidad. Es DECISIÓN. Cada mañana tienes una oportunidad de ser MEJOR que ayer. No esperes el momento perfecto, CRÉALO. Tu futuro depende de lo que hagas HOY. ¡LEVÁNTATE y CONQUISTA tus sueños! 💪",
        superación: "💪 Cada CAÍDA es una lección. Cada OBSTÁCULO, una oportunidad de crecer. No eres víctima de tus circunstancias, eres el ARQUITECTO de tu destino. La SUPERACIÓN comienza cuando decides que YA BASTA de excusas. ¡HOY es tu día! 🚀",
        libertad: "🦅 La verdadera LIBERTAD no se encuentra afuera, se construye ADENTRO. Libérate de las opiniones ajenas, de los miedos que te limitan. Tu LIBERTAD está en tus decisiones, en tu coraje para ser AUTÉNTICO. ¡Vuela alto! ✨"
      },
      sadness: {
        pérdida: "💔 El dolor que sientes HOY es la fuerza que necesitarás MAÑANA. Cada lágrima riega las semillas de tu crecimiento. No tengas miedo de sentir, porque en la TRISTEZA también hay belleza. Tu corazón sabe sanar. 🌱",
        soledad: "🌙 En la SOLEDAD encuentras tu verdadera voz. No estás solo, estás en compañía de tu alma más auténtica. Abraza estos momentos, porque en ellos descubres quién realmente eres. La soledad es tu maestra. 💫",
        nostalgia: "🍂 Los recuerdos son tesoros que nadie puede robarte. Cada momento vivido te ha traído hasta AQUÍ. Honra tu pasado, pero no vivas en él. El presente es tu regalo más preciado. 🎁"
      },
      inspiration: {
        sueños: "✨ Tus SUEÑOS no tienen fecha de vencimiento. Cada día que despiertas es una nueva oportunidad de acercarte a ellos. No importa tu edad, tu situación. Si puedes SOÑARLO, puedes LOGRARLO. ¡Empieza HOY! 🌟",
        creatividad: "🎨 Tu CREATIVIDAD es tu superpoder único. No hay nadie en el mundo que vea las cosas como TÚ las ves. Deja que tu imaginación vuele, que tu arte hable. El mundo necesita tu visión única. ¡CREA sin límites! 🚀",
        amor: "❤️ El AMOR que das siempre regresa multiplicado. Ama sin condiciones, sin expectativas. El amor verdadero transforma todo lo que toca. Empieza por amarte a ti mismo, y verás cómo cambia tu mundo. 💕"
      }
    };

    const emotionScripts = scripts[emotion] || scripts.motivation;
    const availableKeywords = Object.keys(emotionScripts);
    const matchingKeyword = availableKeywords.find(k => k.toLowerCase().includes(keyword.toLowerCase())) || availableKeywords[0];
    
    return emotionScripts[matchingKeyword] || emotionScripts[availableKeywords[0]];
  };

  const generateVideoContent = async () => {
    if (!user) {
      toast({
        title: "¡Inicia sesión primero! 🔐",
        description: "Necesitas una cuenta para generar contenido.",
        variant: "destructive"
      });
      return;
    }

    const limitCheck = checkDailyLimit(user);
    if (!limitCheck.canGenerate) {
      toast({
        title: "¡Límite diario alcanzado! 📊",
        description: `Has usado tus ${limitCheck.limit} videos gratuitos de hoy. ¡Hazte Premium para videos ilimitados!`,
        variant: "destructive"
      });
      setCurrentView('pricing');
      return;
    }

    if (!keyword.trim()) {
      toast({
        title: "¡Oops!",
        description: "Por favor, escribe una palabra clave primero.",
        variant: "destructive"
      });
      return;
    }
    
    if (!selectedEmotion) {
      toast({
        title: "¡Oops!",
        description: "Por favor, selecciona una emoción primero.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    
    setTimeout(() => {
      const script = generateVideoScript(keyword, selectedEmotion);
      const emotionData = emotions.find(e => e.id === selectedEmotion);
      
      const content = {
        id: Date.now(),
        type: contentType,
        keyword: keyword,
        emotion: selectedEmotion,
        emotionName: emotionData?.name || 'Motivación',
        script: script,
        createdAt: new Date().toISOString(),
        videoUrl: contentType === 'video' ? `https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=800&h=450&fit=crop` : null,
        duration: contentType === 'video' ? '0:45' : null,
        views: Math.floor(Math.random() * 10000) + 1000,
        hasWatermark: !user.isPremium,
        isPremium: user.isPremium || false
      };
      
      setGeneratedContent(content);
      
      const updatedUser = { ...user };
      if (contentType === 'video') {
        updatedUser.videos = [...(updatedUser.videos || []), content];
      } else {
        updatedUser.scripts = [...(updatedUser.scripts || []), content];
      }
      
      localStorage.setItem('viralmind_user', JSON.stringify(updatedUser));
      setUser(updatedUser);
      setIsGenerating(false);
      
      const remainingAfter = checkDailyLimit(updatedUser);
      
      toast({
        title: `¡${contentType === 'video' ? 'Video' : 'Guión'} generado! 🎉`,
        description: user.isPremium 
          ? `Tu contenido sobre "${keyword}" está listo.`
          : `Te quedan ${remainingAfter.remaining} videos gratuitos hoy.`
      });
    }, 3000);
  };

  const appProps = {
    selectedEmotion,
    setSelectedEmotion,
    keyword,
    setKeyword,
    user,
    setUser,
    isGenerating,
    generatedContent,
    setGeneratedContent,
    contentType,
    setContentType,
    currentView,
    setCurrentView,
    emotions,
    generateVideoContent,
    checkDailyLimit,
    toast
  };

  return (
    <>
      <Helmet>
        <title>ViralMind AI - Transforma emociones en vídeos virales</title>
        <meta name="description" content="ViralMind AI convierte tus ideas en contenido poderoso usando IA. Genera vídeos motivacionales, emocionales y reflexivos con solo una palabra. Simple, rápido y gratis." />
      </Helmet>

      <div className="animated-bg"></div>
      
      <div className="min-h-screen relative">
        <Header {...appProps} />

        {currentView === 'pricing' ? (
          <PricingSection {...appProps} />
        ) : generatedContent ? (
          <VideoResult {...appProps} />
        ) : (
          <>
            <HeroSection {...appProps} />
            <VideoExamples {...appProps} />
            <ContentGenerator {...appProps} />
            <HowItWorks />
            <CTASection {...appProps} />
          </>
        )}

        <Footer {...appProps} />
        <Toaster />
      </div>
    </>
  );
}

export default App;