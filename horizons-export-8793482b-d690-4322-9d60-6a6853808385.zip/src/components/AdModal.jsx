import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Play, ShoppingCart, Download, Star, Zap, Crown } from 'lucide-react';

function AdModal({ isOpen, onClose, onAdComplete, toast }) {
  const [currentAd, setCurrentAd] = useState(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [canSkip, setCanSkip] = useState(false);
  const [adCompleted, setAdCompleted] = useState(false);

  const ads = [
    {
      id: 1,
      type: 'video',
      title: 'NordVPN - Protege tu privacidad online',
      description: '¡Navega seguro con la VPN #1 del mundo!',
      image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&h=450&fit=crop',
      cta: 'Obtener 70% de descuento',
      duration: 15,
      skipAfter: 5,
      color: 'from-blue-600 to-blue-800'
    },
    {
      id: 2,
      type: 'banner',
      title: 'Shopify - Crea tu tienda online',
      description: 'Vende online con la plataforma más confiable',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=450&fit=crop',
      cta: 'Prueba gratis 14 días',
      duration: 10,
      skipAfter: 3,
      color: 'from-green-600 to-green-800'
    },
    {
      id: 3,
      type: 'product',
      title: 'Audible - Escucha libros donde quieras',
      description: 'Miles de audiolibros y podcasts exclusivos',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=450&fit=crop',
      cta: 'Primer mes gratis',
      duration: 12,
      skipAfter: 4,
      color: 'from-orange-600 to-orange-800'
    },
    {
      id: 4,
      type: 'app',
      title: 'Duolingo Plus - Aprende idiomas',
      description: 'Domina un nuevo idioma en solo 15 min/día',
      image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&h=450&fit=crop',
      cta: 'Descargar gratis',
      duration: 8,
      skipAfter: 3,
      color: 'from-green-500 to-blue-500'
    },
    {
      id: 5,
      type: 'service',
      title: 'Canva Pro - Diseña como un profesional',
      description: 'Plantillas premium y herramientas avanzadas',
      image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&h=450&fit=crop',
      cta: 'Prueba Pro gratis',
      duration: 10,
      skipAfter: 4,
      color: 'from-purple-600 to-pink-600'
    }
  ];

  useEffect(() => {
    if (isOpen && !currentAd) {
      const randomAd = ads[Math.floor(Math.random() * ads.length)];
      setCurrentAd(randomAd);
      setTimeLeft(randomAd.duration);
      setCanSkip(false);
      setAdCompleted(false);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen || !currentAd || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        const newTime = prev - 1;
        if (newTime <= currentAd.duration - currentAd.skipAfter && !canSkip) {
          setCanSkip(true);
        }
        if (newTime <= 0) {
          setAdCompleted(true);
          return 0;
        }
        return newTime;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, currentAd, timeLeft, canSkip]);

  const handleClose = () => {
    if (adCompleted) {
      onAdComplete();
      toast({
        title: "¡Anuncio completado! 🎉",
        description: "La marca de agua ha sido removida de tu video."
      });
    }
    setCurrentAd(null);
    setTimeLeft(0);
    setCanSkip(false);
    setAdCompleted(false);
    onClose();
  };

  const handleSkip = () => {
    if (canSkip || adCompleted) {
      handleClose();
    }
  };

  const handleAdClick = () => {
    toast({
      title: "🚧 Esta función aún no está implementada",
      description: "¡Pero no te preocupes! Puedes solicitarla en tu próximo prompt! 🚀"
    });
  };

  if (!currentAd) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl w-full bg-gray-900 border-gray-700 text-white p-0 overflow-hidden">
        <div className="relative">
          <div className="absolute top-4 right-4 z-10 flex items-center space-x-2">
            <div className="bg-black bg-opacity-70 px-3 py-1 rounded-full text-sm">
              {timeLeft > 0 ? `${timeLeft}s` : 'Completado'}
            </div>
            {(canSkip || adCompleted) && (
              <Button
                onClick={handleSkip}
                size="sm"
                className="bg-gray-700 hover:bg-gray-600 text-white"
              >
                <X className="w-4 h-4 mr-1" />
                {adCompleted ? 'Cerrar' : 'Saltar'}
              </Button>
            )}
          </div>

          <div className="aspect-video relative overflow-hidden">
            <img 
              src={currentAd.image}
              alt={currentAd.title}
              className="w-full h-full object-cover"
            />
            <div className={`absolute inset-0 bg-gradient-to-t ${currentAd.color} bg-opacity-60`}></div>
            
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="text-center"
              >
                <div className="w-20 h-20 mx-auto mb-4 bg-white bg-opacity-20 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-3xl font-bold mb-2 text-white drop-shadow-lg">
                  {currentAd.title}
                </h2>
                <p className="text-xl text-white drop-shadow-md mb-6">
                  {currentAd.description}
                </p>
              </motion.div>
            </div>

            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-gray-300">Anuncio</span>
                </div>
                
                <Button
                  onClick={handleAdClick}
                  className="bg-white text-black hover:bg-gray-200 font-bold px-6 py-2"
                >
                  {currentAd.type === 'video' && <Play className="w-4 h-4 mr-2" />}
                  {currentAd.type === 'banner' && <Star className="w-4 h-4 mr-2" />}
                  {currentAd.type === 'product' && <Download className="w-4 h-4 mr-2" />}
                  {currentAd.type === 'app' && <Zap className="w-4 h-4 mr-2" />}
                  {currentAd.type === 'service' && <Crown className="w-4 h-4 mr-2" />}
                  {currentAd.cta}
                </Button>
              </div>
            </div>
          </div>

          <AnimatePresence>
            {adCompleted && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="absolute inset-0 bg-black bg-opacity-80 flex items-center justify-center"
              >
                <div className="text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", duration: 0.6 }}
                    className="w-20 h-20 mx-auto mb-4 bg-green-500 rounded-full flex items-center justify-center"
                  >
                    <Star className="w-10 h-10 text-white" />
                  </motion.div>
                  <h3 className="text-2xl font-bold mb-2 text-white">
                    ¡Anuncio completado!
                  </h3>
                  <p className="text-gray-300 mb-6">
                    La marca de agua ha sido removida de tu video
                  </p>
                  <Button
                    onClick={handleClose}
                    className="bg-electric text-black hover:bg-white font-bold px-8 py-3"
                  >
                    Continuar
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700">
            <motion.div
              className="h-full bg-electric"
              initial={{ width: "100%" }}
              animate={{ width: `${((currentAd.duration - timeLeft) / currentAd.duration) * 100}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default AdModal;