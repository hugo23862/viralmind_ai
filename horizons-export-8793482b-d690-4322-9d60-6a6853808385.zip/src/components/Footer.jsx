import React from 'react';
import { Sparkles } from 'lucide-react';

function Footer({ toast }) {
  const handleFeatureClick = (feature) => {
    toast({
      title: "🚧 Esta función aún no está implementada",
      description: "¡Pero no te preocupes! Puedes solicitarla en tu próximo prompt! 🚀"
    });
  };

  return (
    <footer className="container mx-auto px-4 py-12 border-t border-gray-800">
      <div className="text-center">
        <div className="flex items-center justify-center space-x-2 mb-6">
          <div className="w-8 h-8 bg-electric rounded-lg flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-black" />
          </div>
          <span className="text-xl font-bold gradient-text">ViralMind AI</span>
        </div>
        <p className="text-gray-400 mb-4">
          Transformando emociones en contenido viral desde 2024
        </p>
        <div className="flex justify-center space-x-6 text-sm text-gray-500">
          <span 
            className="hover:text-electric cursor-pointer transition-colors"
            onClick={() => handleFeatureClick('privacy')}
          >
            Privacidad
          </span>
          <span 
            className="hover:text-electric cursor-pointer transition-colors"
            onClick={() => handleFeatureClick('terms')}
          >
            Términos
          </span>
          <span 
            className="hover:text-electric cursor-pointer transition-colors"
            onClick={() => handleFeatureClick('contact')}
          >
            Contacto
          </span>
        </div>
      </div>
    </footer>
  );
}

export default Footer;