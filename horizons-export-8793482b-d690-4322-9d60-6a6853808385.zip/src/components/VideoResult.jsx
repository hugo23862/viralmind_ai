import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { FileText, Download, Share2, Crown, Eye } from 'lucide-react';
import AdModal from '@/components/AdModal';
import VideoPlayer from '@/components/VideoPlayer';

function VideoResult({ generatedContent, setGeneratedContent, toast, setCurrentView, user, setUser }) {
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);
  const [videoWithoutWatermark, setVideoWithoutWatermark] = useState(false);

  const handleDownload = () => {
    if (generatedContent.hasWatermark && !videoWithoutWatermark) {
      toast({
        title: "Video con marca de agua 💧",
        description: "Este video incluye marca de agua. Hazte Premium para descargas sin marca."
      });
    } else {
      toast({
        title: "¡Descarga iniciada! 📥",
        description: "Tu contenido se está descargando..."
      });
    }
  };

  const handleShare = () => {
    toast({
      title: "¡Enlace copiado! 📋",
      description: "El enlace para compartir se copió al portapapeles."
    });
  };

  const handleWatchAd = () => {
    setIsAdModalOpen(true);
  };

  const handleAdComplete = () => {
    setVideoWithoutWatermark(true);
    
    const updatedContent = {
      ...generatedContent,
      hasWatermark: false,
      adWatched: true
    };
    setGeneratedContent(updatedContent);

    if (user) {
      const updatedUser = { ...user };
      const videoIndex = updatedUser.videos?.findIndex(v => v.id === generatedContent.id);
      if (videoIndex !== -1) {
        updatedUser.videos[videoIndex] = updatedContent;
        localStorage.setItem('viralmind_user', JSON.stringify(updatedUser));
        setUser(updatedUser);
      }
    }
  };

  const handleVideoPlay = () => {
    toast({
      title: "¡Reproduciendo video! 🎬",
      description: "Tu contenido generado con IA está en reproducción."
    });
  };

  const currentVideoHasWatermark = generatedContent.hasWatermark && !videoWithoutWatermark;

  return (
    <>
      <section className="container mx-auto px-4 py-20">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-8">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              ¡Tu {generatedContent.type === 'video' ? 'vídeo' : 'guión'} está <span className="text-electric">listo</span>! 🎉
            </h2>
            <p className="text-xl text-gray-300">
              Palabra clave: "{generatedContent.keyword}" • Emoción: {generatedContent.emotionName}
            </p>
            {currentVideoHasWatermark && (
              <div className="mt-4 p-3 bg-yellow-500 bg-opacity-20 border border-yellow-500 rounded-lg max-w-md mx-auto">
                <p className="text-yellow-300 text-sm">
                  💧 Este video incluye marca de agua (Plan Gratuito)
                </p>
              </div>
            )}
            {videoWithoutWatermark && generatedContent.hasWatermark && (
              <div className="mt-4 p-3 bg-green-500 bg-opacity-20 border border-green-500 rounded-lg max-w-md mx-auto">
                <p className="text-green-300 text-sm">
                  ✨ ¡Marca de agua removida! Gracias por ver el anuncio
                </p>
              </div>
            )}
          </div>

          <div className="bg-gray-800 bg-opacity-50 rounded-3xl p-8 border border-gray-700 mb-8">
            {generatedContent.type === 'video' && (
              <div className="aspect-video mb-6">
                <VideoPlayer
                  videoUrl={generatedContent.videoUrl}
                  hasWatermark={currentVideoHasWatermark}
                  isPremium={generatedContent.isPremium}
                  onPlay={handleVideoPlay}
                  className="w-full h-full"
                />
                {videoWithoutWatermark && !generatedContent.isPremium && (
                  <div className="absolute top-4 left-4 bg-green-500 bg-opacity-90 px-2 py-1 rounded-full text-xs text-white font-bold">
                    Sin marca de agua
                  </div>
                )}
              </div>
            )}

            <div className="mb-6">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <FileText className="w-5 h-5 mr-2 text-electric" />
                Guión generado:
              </h3>
              <div className="bg-gray-900 p-6 rounded-2xl border border-gray-600">
                <p className="text-lg leading-relaxed">{generatedContent.script}</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-4 justify-center">
              <Button 
                onClick={handleDownload}
                className="bg-electric text-black hover:bg-white font-bold"
              >
                <Download className="w-5 h-5 mr-2" />
                Descargar {currentVideoHasWatermark ? '(con marca)' : ''}
              </Button>
              <Button 
                onClick={handleShare}
                variant="outline"
                className="border-electric text-electric hover:bg-electric hover:text-black"
              >
                <Share2 className="w-5 h-5 mr-2" />
                Compartir
              </Button>
              {currentVideoHasWatermark && (
                <>
                  <Button 
                    onClick={handleWatchAd}
                    variant="outline"
                    className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black"
                  >
                    <Eye className="w-5 h-5 mr-2" />
                    Ver Anuncio (Quitar Marca)
                  </Button>
                  <Button 
                    onClick={() => setCurrentView('pricing')}
                    className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white hover:from-yellow-600 hover:to-orange-600 font-bold"
                  >
                    <Crown className="w-5 h-5 mr-2" />
                    Hazte Premium
                  </Button>
                </>
              )}
              <Button 
                onClick={() => setGeneratedContent(null)}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Crear Nuevo
              </Button>
            </div>
          </div>

          {!user?.isPremium && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-center bg-gradient-to-r from-gray-900 to-gray-800 rounded-3xl p-8 border border-gray-700"
            >
              <h3 className="text-2xl font-bold mb-4">
                ¿Te gusta el resultado? <span className="text-electric">¡Hazte Premium!</span>
              </h3>
              <p className="text-gray-300 mb-6">
                Videos ilimitados, sin marca de agua, calidad HD y mucho más por solo €3/mes
              </p>
              <Button 
                onClick={() => setCurrentView('pricing')}
                className="bg-electric text-black hover:bg-white font-bold px-8 py-3"
              >
                <Crown className="w-5 h-5 mr-2" />
                Ver Planes Premium
              </Button>
            </motion.div>
          )}
        </motion.div>
      </section>

      <AdModal 
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        onAdComplete={handleAdComplete}
        toast={toast}
      />
    </>
  );
}

export default VideoResult;