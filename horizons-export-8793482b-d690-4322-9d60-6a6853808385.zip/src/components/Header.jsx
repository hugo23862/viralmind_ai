import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, User, LogOut, Crown } from 'lucide-react';

function Header({ user, setUser, toast, setCurrentView, checkDailyLimit }) {
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '' });

  const handleAuth = (e) => {
    e.preventDefault();
    
    if (authMode === 'register') {
      if (!authForm.name || !authForm.email || !authForm.password) {
        toast({
          title: "¡Oops!",
          description: "Por favor, completa todos los campos.",
          variant: "destructive"
        });
        return;
      }
      
      const newUser = {
        id: Date.now(),
        name: authForm.name,
        email: authForm.email,
        createdAt: new Date().toISOString(),
        videos: [],
        scripts: [],
        isPremium: false
      };
      
      localStorage.setItem('viralmind_user', JSON.stringify(newUser));
      setUser(newUser);
      setIsAuthOpen(false);
      setAuthForm({ email: '', password: '', name: '' });
      
      toast({
        title: "¡Bienvenido a ViralMind AI! 🎉",
        description: "Tu cuenta ha sido creada exitosamente."
      });
    } else {
      if (!authForm.email || !authForm.password) {
        toast({
          title: "¡Oops!",
          description: "Por favor, ingresa email y contraseña.",
          variant: "destructive"
        });
        return;
      }
      
      const mockUser = {
        id: 1,
        name: "Usuario Demo",
        email: authForm.email,
        createdAt: new Date().toISOString(),
        videos: [],
        scripts: [],
        isPremium: false
      };
      
      localStorage.setItem('viralmind_user', JSON.stringify(mockUser));
      setUser(mockUser);
      setIsAuthOpen(false);
      setAuthForm({ email: '', password: '', name: '' });
      
      toast({
        title: "¡Bienvenido de vuelta! 🚀",
        description: "Has iniciado sesión exitosamente."
      });
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('viralmind_user');
    setUser(null);
    setCurrentView('home');
    toast({
      title: "¡Hasta pronto! 👋",
      description: "Has cerrado sesión exitosamente."
    });
  };

  const limitInfo = user ? checkDailyLimit(user) : null;

  return (
    <motion.header 
      className="container mx-auto px-4 py-6"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <nav className="flex justify-between items-center">
        <div 
          className="flex items-center space-x-2 cursor-pointer"
          onClick={() => setCurrentView('home')}
        >
          <div className="w-10 h-10 bg-electric rounded-lg flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-black" />
          </div>
          <span className="text-2xl font-bold gradient-text">ViralMind AI</span>
        </div>
        
        {user ? (
          <div className="flex items-center space-x-4">
            {user.isPremium ? (
              <div className="flex items-center space-x-2 bg-gradient-to-r from-yellow-500 to-orange-500 px-3 py-1 rounded-full">
                <Crown className="w-4 h-4 text-white" />
                <span className="text-sm font-bold text-white">PREMIUM</span>
              </div>
            ) : (
              <div className="text-sm text-gray-300">
                Videos hoy: {limitInfo?.used || 0}/{limitInfo?.limit || 2}
              </div>
            )}
            <span className="text-sm text-gray-300">¡Hola, {user.name}!</span>
            <Button 
              variant="outline" 
              size="sm"
              className="border-electric text-electric hover:bg-electric hover:text-black"
              onClick={() => setCurrentView('pricing')}
            >
              {user.isPremium ? 'Mi Plan' : 'Hazte Premium'}
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
              onClick={handleLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Salir
            </Button>
          </div>
        ) : (
          <Dialog open={isAuthOpen} onOpenChange={setIsAuthOpen}>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                className="border-electric text-electric hover:bg-electric hover:text-black"
              >
                <User className="w-4 h-4 mr-2" />
                Iniciar Sesión
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-gray-700 text-white">
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold text-center gradient-text">
                  {authMode === 'login' ? 'Iniciar Sesión' : 'Crear Cuenta'}
                </DialogTitle>
              </DialogHeader>
              
              <Tabs value={authMode} onValueChange={setAuthMode} className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-gray-800">
                  <TabsTrigger value="login" className="data-[state=active]:bg-electric data-[state=active]:text-black">
                    Iniciar Sesión
                  </TabsTrigger>
                  <TabsTrigger value="register" className="data-[state=active]:bg-electric data-[state=active]:text-black">
                    Registrarse
                  </TabsTrigger>
                </TabsList>
                
                <form onSubmit={handleAuth} className="space-y-4 mt-6">
                  <TabsContent value="register" className="space-y-4 mt-0">
                    <div>
                      <Label htmlFor="name" className="text-white">Nombre completo</Label>
                      <Input
                        id="name"
                        type="text"
                        value={authForm.name}
                        onChange={(e) => setAuthForm({...authForm, name: e.target.value})}
                        className="bg-gray-800 border-gray-600 text-white"
                        placeholder="Tu nombre"
                      />
                    </div>
                  </TabsContent>
                  
                  <div>
                    <Label htmlFor="email" className="text-white">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={authForm.email}
                      onChange={(e) => setAuthForm({...authForm, email: e.target.value})}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="tu@email.com"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="password" className="text-white">Contraseña</Label>
                    <Input
                      id="password"
                      type="password"
                      value={authForm.password}
                      onChange={(e) => setAuthForm({...authForm, password: e.target.value})}
                      className="bg-gray-800 border-gray-600 text-white"
                      placeholder="••••••••"
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-electric text-black hover:bg-white font-bold"
                  >
                    {authMode === 'login' ? 'Iniciar Sesión' : 'Crear Cuenta'}
                  </Button>
                </form>
              </Tabs>
            </DialogContent>
          </Dialog>
        )}
      </nav>
    </motion.header>
  );
}

export default Header;