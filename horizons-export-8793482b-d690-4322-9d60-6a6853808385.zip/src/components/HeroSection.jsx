import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Play, ArrowRight, Loader2 } from 'lucide-react';

function HeroSection({ generateVideoContent, isGenerating }) {
  return (
    <section className="container mx-auto px-4 py-20 text-center">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-6xl mx-auto"
      >
        <h1 className="text-5xl md:text-7xl font-black mb-8 leading-tight">
          Transforma <span className="gradient-text">emociones</span> en vídeos <span className="text-electric">virales</span> con solo una palabra
        </h1>
        
        <motion.p 
          className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          ViralMind AI convierte tus ideas en contenido poderoso usando IA. Simple, rápido y gratis.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <Button 
            size="lg" 
            className="bg-electric text-black hover:bg-white text-xl px-12 py-6 rounded-full electric-glow pulse-glow font-bold"
            onClick={generateVideoContent}
            disabled={isGenerating}
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                Generando...
              </>
            ) : (
              <>
                <Play className="w-6 h-6 mr-3" />
                Crear mi vídeo con IA ahora
                <ArrowRight className="w-6 h-6 ml-3" />
              </>
            )}
          </Button>
        </motion.div>
      </motion.div>
    </section>
  );
}

export default HeroSection;