import React from 'react';
import { motion } from 'framer-motion';

function HowItWorks() {
  const steps = [
    { step: 1, title: "Escribe una palabra clave", desc: "Cualquier concepto o idea que quieras transmitir", icon: "✍️" },
    { step: 2, title: "Selecciona el tipo de emoción", desc: "Elige el sentimiento que mejor represente tu mensaje", icon: "❤️" },
    { step: 3, title: "Genera el contenido con IA", desc: "Nuestra IA crea videos o guiones únicos en segundos", icon: "🎬" },
    { step: 4, title: "Descárgalo o publícalo", desc: "Comparte tu creación en todas las redes sociales", icon: "🚀" }
  ];

  return (
    <section className="container mx-auto px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <h2 className="text-4xl md:text-5xl font-bold mb-6">
          Cómo <span className="text-electric">funciona</span>
        </h2>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          En solo 4 pasos simples tendrás tu contenido viral listo
        </p>
      </motion.div>

      <div className="grid md:grid-cols-4 gap-8 max-w-6xl mx-auto">
        {steps.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-electric to-blue-400 rounded-full flex items-center justify-center text-3xl">
              {item.icon}
            </div>
            <div className="bg-gray-800 bg-opacity-50 p-6 rounded-2xl border border-gray-700">
              <div className="text-electric text-sm font-bold mb-2">PASO {item.step}</div>
              <h3 className="text-xl font-bold mb-3">{item.title}</h3>
              <p className="text-gray-300">{item.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export default HowItWorks;