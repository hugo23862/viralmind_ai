import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Video, FileText, Sparkles, Loader2, TrendingUp, Heart, Zap, Target, Star } from 'lucide-react';

function ContentGenerator({ 
  selectedEmotion, 
  setSelectedEmotion, 
  keyword, 
  setKeyword, 
  contentType, 
  setContentType, 
  generateVideoContent, 
  isGenerating, 
  emotions,
  user,
  checkDailyLimit
}) {
  const getIconComponent = (iconName) => {
    const icons = {
      TrendingUp,
      Heart,
      Zap,
      Target,
      Sparkles,
      Star
    };
    return icons[iconName] || Sparkles;
  };

  const limitInfo = user ? checkDailyLimit(user) : null;

  return (
    <section className="container mx-auto px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <h2 className="text-4xl md:text-5xl font-bold mb-6">
          Configura tu <span className="text-electric">contenido</span>
        </h2>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Personaliza cada detalle de tu creación
        </p>
        {user && !user.isPremium && (
          <div className="mt-4 p-4 bg-gray-800 bg-opacity-50 rounded-2xl border border-gray-700 max-w-md mx-auto">
            <p className="text-sm text-gray-300">
              Plan Gratuito: {limitInfo?.used || 0}/{limitInfo?.limit || 2} videos hoy
            </p>
            <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
              <div 
                className="bg-electric h-2 rounded-full transition-all duration-300" 
                style={{ width: `${((limitInfo?.used || 0) / (limitInfo?.limit || 2)) * 100}%` }}
              ></div>
            </div>
          </div>
        )}
      </motion.div>

      <div className="max-w-4xl mx-auto mb-12">
        <div className="bg-gray-800 bg-opacity-50 rounded-3xl p-8 border border-gray-700 mb-8">
          <div className="mb-8">
            <Label className="text-xl font-semibold mb-4 block">Tipo de contenido</Label>
            <div className="grid grid-cols-2 gap-4">
              <Button
                variant={contentType === 'video' ? 'default' : 'outline'}
                className={`p-6 h-auto ${contentType === 'video' ? 'bg-electric text-black' : 'border-gray-600 text-gray-300 hover:bg-gray-700'}`}
                onClick={() => setContentType('video')}
              >
                <Video className="w-8 h-8 mb-2" />
                <div>
                  <div className="font-bold">Video Completo</div>
                  <div className="text-sm opacity-80">Con voz e imágenes</div>
                </div>
              </Button>
              <Button
                variant={contentType === 'script' ? 'default' : 'outline'}
                className={`p-6 h-auto ${contentType === 'script' ? 'bg-electric text-black' : 'border-gray-600 text-gray-300 hover:bg-gray-700'}`}
                onClick={() => setContentType('script')}
              >
                <FileText className="w-8 h-8 mb-2" />
                <div>
                  <div className="font-bold">Solo Guión</div>
                  <div className="text-sm opacity-80">Texto optimizado</div>
                </div>
              </Button>
            </div>
          </div>

          <div className="mb-8">
            <Label className="text-xl font-semibold mb-4 block">Escribe tu palabra clave</Label>
            <Input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="Ej: éxito, amor, libertad, superación..."
              className="w-full px-6 py-4 text-xl bg-gray-900 border-2 border-gray-600 rounded-2xl focus:border-electric text-white placeholder-gray-400"
            />
          </div>

          <div className="mb-8">
            <Label className="text-xl font-semibold mb-4 block">Selecciona la emoción</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {emotions.map((emotion, index) => {
                const IconComponent = getIconComponent(emotion.icon);
                return (
                  <motion.div
                    key={emotion.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className={`emotion-card p-4 rounded-2xl border-2 text-center cursor-pointer ${
                      selectedEmotion === emotion.id 
                        ? 'selected border-electric bg-electric bg-opacity-10' 
                        : 'border-gray-600 bg-gray-800 bg-opacity-50 hover:border-gray-500'
                    }`}
                    onClick={() => setSelectedEmotion(emotion.id)}
                  >
                    <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r ${emotion.color} flex items-center justify-center`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-semibold">{emotion.name}</h3>
                  </motion.div>
                );
              })}
            </div>
          </div>
          
          <div className="text-center">
            <Button 
              size="lg" 
              className="bg-electric text-black hover:bg-white text-xl px-12 py-6 rounded-full electric-glow font-bold"
              onClick={generateVideoContent}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                  Generando tu {contentType === 'video' ? 'video' : 'guión'}...
                </>
              ) : (
                <>
                  <Sparkles className="w-6 h-6 mr-3" />
                  Generar {contentType === 'video' ? 'Video' : 'Guión'} Ahora
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default ContentGenerator;