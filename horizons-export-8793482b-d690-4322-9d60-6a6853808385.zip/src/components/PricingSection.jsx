import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Check, Crown, Sparkles, Video, Zap, Star, Mail } from 'lucide-react';
import AdModal from '@/components/AdModal';

function PricingSection({ user, setCurrentView, toast }) {
  const [isPremiumDialogOpen, setIsPremiumDialogOpen] = useState(false);
  const [premiumEmail, setPremiumEmail] = useState('');
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);

  const handlePremiumRequest = (e) => {
    e.preventDefault();
    
    if (!premiumEmail.trim()) {
      toast({
        title: "¡Oops!",
        description: "Por favor, ingresa tu email.",
        variant: "destructive"
      });
      return;
    }

    const emailData = {
      userEmail: premiumEmail,
      userName: user?.name || 'Usuario',
      requestDate: new Date().toISOString(),
      message: `Solicitud de cuenta Premium de ${premiumEmail}. Usuario: ${user?.name || 'No registrado'}`
    };

    console.log('Enviando solicitud Premium a hugo.perezdanta@gmail.com:', emailData);

    toast({
      title: "¡Solicitud enviada! 📧",
      description: `Hemos enviado tu solicitud a hugo.perezdanta@gmail.com. Te contactaremos pronto para activar tu cuenta Premium.`
    });

    setIsPremiumDialogOpen(false);
    setPremiumEmail('');
  };

  const handleWatchAd = () => {
    setIsAdModalOpen(true);
  };

  const handleAdComplete = () => {
    toast({
      title: "¡Anuncio completado! 🎉",
      description: "Ahora puedes crear un video sin marca de agua."
    });
  };

  return (
    <>
      <section className="container mx-auto px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-black mb-6">
            Elige tu <span className="text-electric">plan</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Desde videos gratuitos hasta creación ilimitada premium
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-gray-800 bg-opacity-50 rounded-3xl p-8 border border-gray-700 relative"
          >
            <div className="text-center mb-8">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-gray-600 to-gray-500 rounded-full flex items-center justify-center">
                <Video className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-2">Plan Gratuito</h3>
              <div className="text-4xl font-black mb-2">€0<span className="text-lg text-gray-400">/mes</span></div>
              <p className="text-gray-400">Perfecto para empezar</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500" />
                <span>2 videos por día</span>
              </div>
              <div className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500" />
                <span>Guiones ilimitados</span>
              </div>
              <div className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500" />
                <span>Todas las emociones</span>
              </div>
              <div className="flex items-center space-x-3">
                <Zap className="w-5 h-5 text-yellow-500" />
                <span>Videos con marca de agua</span>
              </div>
              <div className="flex items-center space-x-3">
                <Star className="w-5 h-5 text-blue-500" />
                <span>Quitar marca viendo anuncio</span>
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                className="w-full bg-gray-700 hover:bg-gray-600 text-white"
                onClick={() => setCurrentView('home')}
              >
                {user ? 'Tu Plan Actual' : 'Comenzar Gratis'}
              </Button>
              {user && !user.isPremium && (
                <Button 
                  variant="outline"
                  className="w-full border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black"
                  onClick={handleWatchAd}
                >
                  Ver Anuncio para Quitar Marca
                </Button>
              )}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-gradient-to-br from-electric to-blue-500 rounded-3xl p-8 border-2 border-electric relative overflow-hidden"
          >
            <div className="absolute top-4 right-4 bg-white text-black px-3 py-1 rounded-full text-sm font-bold">
              POPULAR
            </div>
            
            <div className="text-center mb-8">
              <div className="w-16 h-16 mx-auto mb-4 bg-white rounded-full flex items-center justify-center">
                <Crown className="w-8 h-8 text-electric" />
              </div>
              <h3 className="text-2xl font-bold mb-2 text-black">Plan Premium</h3>
              <div className="text-4xl font-black mb-2 text-black">€3<span className="text-lg text-gray-800">/mes</span></div>
              <p className="text-gray-800">Para creadores serios</p>
            </div>

            <div className="space-y-4 mb-8 text-black">
              <div className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-700" />
                <span className="font-medium">Videos ilimitados</span>
              </div>
              <div className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-700" />
                <span className="font-medium">Sin marca de agua</span>
              </div>
              <div className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-700" />
                <span className="font-medium">Calidad HD superior</span>
              </div>
              <div className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-700" />
                <span className="font-medium">Voces premium</span>
              </div>
              <div className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-700" />
                <span className="font-medium">Soporte prioritario</span>
              </div>
              <div className="flex items-center space-x-3">
                <Sparkles className="w-5 h-5 text-yellow-600" />
                <span className="font-medium">Efectos exclusivos</span>
              </div>
            </div>

            <Dialog open={isPremiumDialogOpen} onOpenChange={setIsPremiumDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  className="w-full bg-black text-white hover:bg-gray-800 font-bold text-lg py-6"
                >
                  <Crown className="w-5 h-5 mr-2" />
                  {user?.isPremium ? 'Plan Activo' : 'Hazte Premium'}
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-gray-700 text-white">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold text-center gradient-text">
                    Solicitar Plan Premium
                  </DialogTitle>
                </DialogHeader>
                
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-electric rounded-full flex items-center justify-center">
                      <Mail className="w-8 h-8 text-black" />
                    </div>
                    <p className="text-gray-300">
                      Enviaremos tu solicitud a nuestro equipo para activar tu cuenta Premium
                    </p>
                  </div>
                  
                  <form onSubmit={handlePremiumRequest} className="space-y-4">
                    <div>
                      <Label htmlFor="premium-email" className="text-white">Tu email</Label>
                      <Input
                        id="premium-email"
                        type="email"
                        value={premiumEmail}
                        onChange={(e) => setPremiumEmail(e.target.value)}
                        className="bg-gray-800 border-gray-600 text-white"
                        placeholder="tu@email.com"
                      />
                    </div>
                    
                    <div className="bg-gray-800 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2 text-electric">¿Qué incluye Premium?</h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• Videos ilimitados sin restricciones</li>
                        <li>• Sin marca de agua en tus creaciones</li>
                        <li>• Calidad HD superior y voces premium</li>
                        <li>• Efectos y transiciones exclusivas</li>
                        <li>• Soporte prioritario 24/7</li>
                      </ul>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-electric text-black hover:bg-white font-bold"
                    >
                      Enviar Solicitud Premium
                    </Button>
                  </form>
                </div>
              </DialogContent>
            </Dialog>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center mt-12"
        >
          <p className="text-gray-400 mb-4">
            ¿Tienes preguntas sobre los planes? Contáctanos
          </p>
          <Button 
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
            onClick={() => setCurrentView('home')}
          >
            Volver al Inicio
          </Button>
        </motion.div>
      </section>

      <AdModal 
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        onAdComplete={handleAdComplete}
        toast={toast}
      />
    </>
  );
}

export default PricingSection;