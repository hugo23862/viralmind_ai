import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Play, Loader2 } from 'lucide-react';

function CTASection({ generateVideoContent, isGenerating }) {
  return (
    <section className="container mx-auto px-4 py-20">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
        className="text-center bg-gradient-to-r from-gray-900 to-gray-800 rounded-3xl p-12 border border-gray-700"
      >
        <h2 className="text-4xl md:text-6xl font-black mb-6">
          Tu mente tiene <span className="gradient-text">poder</span>.<br />
          Dale <span className="text-electric">voz</span>.
        </h2>
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Únete a miles de creadores que ya están transformando sus ideas en contenido viral
        </p>
        <Button 
          size="lg" 
          className="bg-electric text-black hover:bg-white text-xl px-12 py-6 rounded-full electric-glow pulse-glow font-bold"
          onClick={generateVideoContent}
          disabled={isGenerating}
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-6 h-6 mr-3 animate-spin" />
              Generando...
            </>
          ) : (
            <>
              <Play className="w-6 h-6 mr-3" />
              Comenzar Gratis Ahora
            </>
          )}
        </Button>
      </motion.div>
    </section>
  );
}

export default CTASection;