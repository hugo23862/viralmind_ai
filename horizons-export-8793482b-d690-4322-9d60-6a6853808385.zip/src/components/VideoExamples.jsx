import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import VideoPlayer from '@/components/VideoPlayer';

function VideoExamples({ toast }) {
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);

  const examples = [
    { 
      keyword: "Superación", 
      emotion: "Motivación", 
      views: "2.3M",
      thumbnail: "https://images.unsplash.com/photo-1528563784587-3d5fc51e8082?w=800&h=450&fit=crop",
      description: "Un video inspirador sobre superar obstáculos y alcanzar tus metas"
    },
    { 
      keyword: "Amor", 
      emotion: "Inspiración", 
      views: "1.8M",
      thumbnail: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=800&h=450&fit=crop",
      description: "Una reflexión emotiva sobre el poder transformador del amor"
    },
    { 
      keyword: "Libertad", 
      emotion: "Reflexión", 
      views: "3.1M",
      thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=450&fit=crop",
      description: "Un mensaje profundo sobre la verdadera libertad interior"
    }
  ];

  const handleVideoClick = (example) => {
    setSelectedVideo(example);
    setIsVideoModalOpen(true);
    toast({
      title: `Reproduciendo: ${example.keyword} 🎬`,
      description: `Video de ${example.emotion} con ${example.views} visualizaciones`
    });
  };

  return (
    <>
      <section className="container mx-auto px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ejemplos de vídeos <span className="text-electric">generados</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Mira el poder de la IA transformando simples palabras en contenido viral
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {examples.map((example, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="relative group cursor-pointer"
              onClick={() => handleVideoClick(example)}
            >
              <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl overflow-hidden border border-gray-700 group-hover:border-electric transition-all duration-300 relative">
                <img  
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                  alt={`Video motivacional ejemplo ${index + 1}`}
                  src={example.thumbnail} 
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-16 h-16 bg-electric rounded-full flex items-center justify-center hover:bg-white transition-colors duration-200">
                    <svg className="w-8 h-8 text-black ml-1" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z"/>
                    </svg>
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 bg-black bg-opacity-70 px-3 py-1 rounded-full text-xs text-white">
                  ViralMind AI
                </div>
                <div className="absolute top-4 right-4 bg-electric bg-opacity-90 px-2 py-1 rounded-full text-xs text-black font-bold">
                  DEMO
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-lg font-semibold mb-2">Palabra: "{example.keyword}"</h3>
                <p className="text-gray-400 text-sm">Emoción: {example.emotion} • {example.views} visualizaciones</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <Dialog open={isVideoModalOpen} onOpenChange={setIsVideoModalOpen}>
        <DialogContent className="max-w-4xl w-full bg-gray-900 border-gray-700 text-white p-0">
          {selectedVideo && (
            <div className="p-6">
              <div className="mb-4">
                <h3 className="text-2xl font-bold mb-2">
                  Video de ejemplo: "{selectedVideo.keyword}"
                </h3>
                <p className="text-gray-300">
                  {selectedVideo.description}
                </p>
                <div className="flex items-center space-x-4 mt-2 text-sm text-gray-400">
                  <span>Emoción: {selectedVideo.emotion}</span>
                  <span>•</span>
                  <span>{selectedVideo.views} visualizaciones</span>
                </div>
              </div>
              
              <div className="aspect-video">
                <VideoPlayer
                  videoUrl={selectedVideo.thumbnail}
                  hasWatermark={true}
                  isPremium={false}
                  className="w-full h-full"
                  onPlay={() => toast({
                    title: "¡Video de ejemplo reproduciendo! 🎬",
                    description: "Este es un video de demostración generado con IA"
                  })}
                />
              </div>

              <div className="mt-4 p-4 bg-gray-800 rounded-lg">
                <p className="text-sm text-gray-300">
                  💡 <strong>Nota:</strong> Este es un video de ejemplo. Con ViralMind AI puedes generar contenido personalizado usando tus propias palabras clave y emociones.
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

export default VideoExamples;